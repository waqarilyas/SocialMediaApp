export const postImage1 = require("./postImage1.jpg");
export const postImage2 = require("./postImage2.jpg");
export const postImage3 = require("./postImage3.jpg");
export const postImage4 = require("./postImage4.jpg");
export const postImage5 = require("./postImage5.jpg");

export const userImage1 = require("./userImage1.jpg");
export const userImage2 = require("./userImage2.jpg");
